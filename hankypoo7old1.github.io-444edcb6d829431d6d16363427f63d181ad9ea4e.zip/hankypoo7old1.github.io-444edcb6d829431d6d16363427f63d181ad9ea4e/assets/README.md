Assets
