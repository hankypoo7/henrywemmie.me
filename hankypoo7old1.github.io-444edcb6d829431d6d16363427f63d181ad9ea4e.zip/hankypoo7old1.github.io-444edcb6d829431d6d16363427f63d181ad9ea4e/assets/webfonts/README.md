stuff for images and text ect.
